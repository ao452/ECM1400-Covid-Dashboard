
COVID-19 Personalised Dashboard


==Introduction== 
The purpose of this project is to depict and track UK Covid cases with the help of Python. 
This code allows you to run a personalised dashboard where COVID cases and news are updated and you can select the COVID cases update you want to see. 

==Prerequisites== 
Before continuing, ensure that you have the following requirements met: 
- You have installed Python 3.8.2 
- You are using Windows or MacOS

==Installation==
This module requires the following modules: 
- Requests 
- Pandas 
- Json 
- Time 
- Schedule 
- Csv 


Install pip3 to run the modules
pip3 install 

Install Cov19API
from uk_covid19 import Cov19API

Install NewsApiClient
from newsapi import NewsApiClient

==Testing==

To test the code, use the unittest module 





==Getting started==
The 3 code modules can be found in the folder covid19dashboard_package. The first you should run is covid_data_handler.py, covid_news_handling.py and user_interface_flask.py
 
Go to https://newsapi.org/register and create an account to obtain your own API key. This API key will then be used in the news_API_request function of the covid_news_handling.py. 


==License Information==
MIT License 

==Contributions==
The project can be found on 
Contributions are highly welcomed to improve the code. Please do give suggestions 



