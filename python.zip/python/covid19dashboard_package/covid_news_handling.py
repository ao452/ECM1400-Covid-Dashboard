'''This section of code handles API data for COVID news and news updates'''
import json
import requests
import time

from uk_covid19 import Cov19API
from newsapi import NewsApiClient



def news_API_request(covid_terms = 'Covid Covid-19 coronavirus'):
    '''By specifying covid_terms = 'Covid Covi-19 coronavirus' the API will retrieve news related to COVID-19'''
    url = ('https://newsapi.org/v2/everything?q=''{}&'.format(covid_terms)+ 'apiKey=23e63f20576f4364b7cd657c500cfec8')
    response = requests.get(url)
    print(response.json())

def update_news(news_API_request=news_API_request()):
    return update_news
update_news()
    



