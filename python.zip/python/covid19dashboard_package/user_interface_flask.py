'''This section runs the Flask which helps you to run the COVID Dashboard. Functions from covid_data_handler.py and covid_news_handling.py are imported.'''
from flask import Flask
from flask import render_template
import requests
import json
from covid_data_handler import covid_API_request
from covid_news_handling import news_API_request
from covid_news_handling import update_news
from newsapi import NewsApiClient

app = Flask(__name__)
@app.route('/index')
def hello():
    covid_news = news_API_request()
    news = covid_news["articles"]     
    news_updates = update_news()  
    covid_update = covid_API_request()["data"][0]
    covid_update1 = covid_API_request("England", "nation")["data"][0]
    localcases7 = covid_update["newCasesByPublishDate"][1:7]
    nationalcases7 = covid_update1["cumCasesByPublishDate"][1:7]
    hospcases = covid_update1["hospitalCases"]
    deathcases = covid_update1["cumDailyNsoDeathsByDeathDate"]


    return render_template('index.html', 
        title='Daily COVID update', news_articles = news[0:7], updates=news_updates, local_7day_infections=localcases7, national_7day_infections=nationalcases7, hospital_cases=hospcases, 
        location="Exeter", nation_location="England", deaths_total=deathcases, image="Coronavirus-CDC-645x645.jpeg", content="m")

if __name__ == '__main__':
   app.run()
