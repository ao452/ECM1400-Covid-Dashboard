import sched 
import time
import csv  
import json
import numpy as np
import pandas as pd
import requests



from uk_covid19 import Cov19API



def parse_csv_data(csv_file_name) -> str:
    '''The function parse_csv_data prints out the lines from csv file nation_2021-10-28.csv
    open(csv_file_name, 'r').readlines(): retrieves the csv file'''
    csv_list = []
    lines = open(csv_file_name, 'r').readlines()
    
    for line in lines:
        csv_list.append(line)
        
    return csv_list
a = parse_csv_data("nation_2021-10-28.csv")

print(a)
        

#data processing using pandas 

def process_csv_data():
    '''The function process_csv_data prints . This is done with the pandas module,
    the number of cases in the last 7 days, the current number of hospital cases and the cumulative number of deaths are returned
    pd.read.csv(): loads the csv into a dataframe '''
    df = pd.read_csv('nation_2021-10-28.csv')
    cols_to_sum= ['newCasesBySpecimenDate']
    number_of_cases_in_the_last_7days = df[cols_to_sum][1:8].sum()
    current_number_of_hospitalcases = df["hospitalCases"]
    cumulative_number_of_deaths = df["cumDailyNsoDeathsByDeathDate"]
    return number_of_cases_in_the_last_7days, current_number_of_hospitalcases, cumulative_number_of_deaths
#covid_API_request retrieved from Public Health England   

def covid_API_request(location = "Exeter", location_type = "ltla"):
    '''
    api.get_json(): COVID API is extracted via json'''
    england_only = [
    'areaType=nation',
    'areaName=England'
    ]
    

    cases_and_deaths = {
        "date": "date",
        "areaName": "areaName",
        "areaCode": "areaCode",
        "newCasesByPublishDate": "newCasesByPublishDate",
        "cumCasesByPublishDate": "cumCasesByPublishDate",
        "hospitalCases": "hospitalCases",
        "cumDailyNsoDeathsByDeathDate": "cumDailyNsoDeathsByDeathDate",
        

    

    }
    api = Cov19API(filters=england_only, structure=cases_and_deaths)
    data = api.get_json()
    print(data)
covid_API_request()
    




def schedule_covid_updates():    
    update_name = "test"
    update_interval = time(30)





















